
#include "robotOnLine.h"

/*
  INPUTS ONLY
  (No internall pulls)  
    GPIO34
    GPIO35
    GPIO36
    GPIO37
    GPIO38
    GPIO39

*/
//#define DEBUG 1

#define PWM_Frequency 5000  // this variable is used to define the time period, up to 312.5kHz
#define _IN1_PWM_channel 0 // this variable is used to select the channel number
#define _IN2_PWM_channel 1 // there are 15 channels, choose between 0 to 15 (not related to the pins)
#define _IN3_PWM_channel 2 //
#define _IN4_PWM_channel 3 //
#define PWM_RESOUTION 8    // this will define the resolution of the signal which is 8 in this case

#define PWM 1 //by defining "PWM" we'll be using the PWM function to control the motors
#define doSpeedAdjustment 1 // enables the functions to match the wheels speed
#define encoderOffset 1 // used to match the wheels speed, this "1" is how much (encoder pulses) a wheel can be ahead or behind the other

// dutty cycles to control the various motor speeds
byte _fastSpeed = 255;
byte _averageSpeed = 225;
byte _slowSpeed = 200;

bool _disableUltrasonicSensor = 0;
bool _disableNearSensor = 0;
bool _disableCLPSensor = 0;

//all the processing to match the wheels speed is done inside the autoDrive() function
extern bool _maneuver = 1; // remenbers if the robot did any maneuver
bool _lastEncoderOffsetMatch = 0; //remenbers if lasst time the wheels speed matched
bool _fixDirAlways = 1; //will constantly attempt to match wheels speed

// for speed adjustment
byte _encoderAhead = 0; //4Most Significant Bits -> Left, 4Less SB -> right
bool _encoderOsc = 0;   //warns if the motor speed can't match
uint _eso=2; //encoder step offset

volatile int8_t robotOnLine::_speedAdjR = 0;
volatile int8_t robotOnLine::_speedAdjL = 0;

byte _stopDistance = 9; // distance in cm at wich the robot will stop

byte _LLS1 = 25;
 volatile byte robotOnLine::_LS2 = 33;
 volatile byte robotOnLine::_MS3 = 32;
 volatile byte robotOnLine::_RS4 = 35;
byte _RRS5 = 34;
 volatile byte robotOnLine::_CLP = 39; 
byte _Near = 36;

volatile byte robotOnLine::_wheelL = 26; 
volatile byte robotOnLine::_wheelR = 27; 

//motor pins IN1&IN2 right engine
byte _IN1 = 4; //IO15 and 5 are HIGH during boot.
byte _IN2 = 16;
//IN3&IN4 left engine
byte _IN3 = 17;
byte _IN4 = 18;
//IR interruption sensor pins, 20 wholes
/* byte _wheelL = 26;
byte _wheelR = 27; */

byte _trig = 14;
byte _echo = 12;

extern volatile byte _LLP = 0;  // tells which sensor "saw" the line last time 1 to 5
/*  0 no line found.
    1 line of left
    2 line on middle
    3 line on right
    4 multiple lines found
    5 obstacle found
    11 Motors will turn left after the _invDel ms
    13 Motors will turn right after the _invDel ms
    14 Just missed a crossroad, reversing..
*/
extern volatile unsigned long _timeOut=0;

uint _dif=700;
uint _invDel=100; //delay to wait before inverting motors polarity (e.g. making both motors move in the oposite direction)
//volatile uint _Right = 0, _Left = 0;

E32_PC0 PC0;
E32_PC1 PC1;

int16_t robotOnLine::getRightEncoderCount()
{ // returns the number of pulse's of the right encoder
  return PC1.getCount();// pin 27
}

int16_t robotOnLine::getLeftEncoderCount()
{ // returns the number of pulse's of the left encoder
  return PC0.getCount();// pin 26
}

void robotOnLine::clearEncoderCount()
{ //set's the number of counted encoder pulse's back to zero
  PC0.clearCount();
  PC1.clearCount();
}

void robotOnLine::editWheelPin(uint8_t _wheeL, uint8_t _wheeR)
{
  _wheelL = _wheeL;
  _wheelR = _wheeR;
}

void robotOnLine::editMotorPin(uint8_t _in1, uint8_t _in2, uint8_t _in3, uint8_t _in4)
{
  _IN1 = _in1;
  _IN2 = _in2;
  _IN3 = _in3;
  _IN4 = _in4;
}

void robotOnLine::editUltrasonicPin(uint8_t _tri, uint8_t _ech)
{
  _trig = _tri;
  _echo = _ech;
}

void robotOnLine::editSensorPin(uint8_t _SS1, uint8_t _SS2, uint8_t _SS3, uint8_t _SS4, uint8_t _SS5, uint8_t __CLP, uint8_t __Near)
{
  _LLS1 = _SS1;
  _LS2 = _SS2;
  _MS3 = _SS3;
  _RS4 = _SS4;
  _RRS5 = _SS5;
  _Near = __Near;
  _CLP = __CLP;
}

void robotOnLine::_config()
{
  //For the front Board with 6xIR sensors
  pinMode(_LLS1, INPUT);
  pinMode(_LS2, INPUT);
  pinMode(_MS3, INPUT);
  pinMode(_RS4, INPUT);
  pinMode(_RRS5, INPUT);
  pinMode(_CLP, INPUT);
  pinMode(_Near, INPUT);

  //for the motor conroll
  pinMode(_IN1, OUTPUT);
  pinMode(_IN2, OUTPUT);
  pinMode(_IN3, OUTPUT);
  pinMode(_IN4, OUTPUT);

  //for the wheels IR sensors
  pinMode(_wheelL, INPUT);
  pinMode(_wheelR, INPUT);

  //for the ultrasonic sensor
  pinMode(_trig, OUTPUT);
  pinMode(_echo, INPUT);
}

byte robotOnLine::distance()
{ // returns the distance (in cm) measured by the ultrasonic sensor
  digitalWrite(_trig, LOW);
  delayMicroseconds(2);

  digitalWrite(_trig, HIGH);
  delayMicroseconds(10);
  digitalWrite(_trig, LOW);

  uint32_t duration = pulseIn(_echo, HIGH);

  uint dist = int(duration * 0.034f / 2.f);
  if (dist > 255)
  {
    return 255;
  }
  else
  {
    return dist;
  }
}

void robotOnLine::setStopDistance(byte d)
{
  _stopDistance=d;
}

void robotOnLine::disableCLP()
{
  _disableCLPSensor=1;
}
void robotOnLine::disableNear()
{
  _disableNearSensor=1;
}
void robotOnLine::disableUltrasonic()
{
  _disableUltrasonicSensor=1;
}

byte robotOnLine::checkSensors()
{
  byte data=0;
  byte d[8] = {0, 0, 0, 0, 0, 0, 0}; 
  // 0 (impact switch), 1 (far left) , 2 (left) , 3 (middle),
  //code for line following part
  d[6] = !digitalRead(_LLS1);
  d[5] = !digitalRead(_LS2);
  d[4] = !digitalRead(_MS3); // if d[4] is 1, it means there is a line
  d[3] = !digitalRead(_RS4);
  d[2] = !digitalRead(_RRS5);
  d[1] = digitalRead(_CLP);
  d[0] = digitalRead(_Near);

  for (size_t i = 0; i < 7; i++)
  {
    data |= (d[i] << (i+1) ) ;
  }
  return data;
}

void IRAM_ATTR _think()
{ 
  noInterrupts();
  #ifdef DEBUG
  Serial.print("*");
  #endif

  _maneuver=1;

  if(digitalRead(robotOnLine::_CLP))
  {
    ledcWrite(_IN1_PWM_channel, 0);
    ledcWrite(_IN2_PWM_channel, 0);
    ledcWrite(_IN3_PWM_channel, 0);
    ledcWrite(_IN4_PWM_channel, 0);
    _LLP=5;
    return;
  }
  bool a=0,b=0,c=0;
  a=!digitalRead(robotOnLine::_LS2);
  b=!digitalRead(robotOnLine::_MS3);
  c=!digitalRead(robotOnLine::_RS4);
  // a,b or c is 1 if a line is found.
  if( ((a&&b) || (b&&c) || (a&&c)) && (_LLP!=4) ){
    if(a){  //checking if this is a false alarm, may happen during curves
      if(digitalRead(_LLS1)){ //if no line found on far left, false alarm
        return;
      }
    }else if(c){
      if(digitalRead(_RRS5)){ //if no line found on far right, false alarm
        return;
      }
    }
    ledcWrite(_IN1_PWM_channel, 0);
    ledcWrite(_IN2_PWM_channel, 0);
    ledcWrite(_IN3_PWM_channel, 0);
    ledcWrite(_IN4_PWM_channel, 0);
    _LLP=4;
  }else if((!a && b && !c) && (_LLP!=2)){
    ledcWrite(_IN1_PWM_channel, 0);
    ledcWrite(_IN2_PWM_channel, abs(_fastSpeed-robotOnLine::_speedAdjR));
    ledcWrite(_IN3_PWM_channel, abs(_fastSpeed-robotOnLine::_speedAdjL));
    ledcWrite(_IN4_PWM_channel, 0);
    _maneuver=0; _LLP=2;
  }else if((a && !b && !c) && ((_LLP!=1)&&(_LLP!=11))){
    if(_LLP==3 || _LLP==13 || _LLP == 0){//if motors were rotating right
      ledcWrite(_IN1_PWM_channel, 0);
      ledcWrite(_IN3_PWM_channel, 0);
      _timeOut=millis();  //let's wait before rotating left
      _LLP=11;
      #ifdef DEBUG
      Serial.print("Halt!");
      #endif
    }else{
      //right engine forward
      ledcWrite(_IN1_PWM_channel, 0);
      ledcWrite(_IN2_PWM_channel, _averageSpeed);// fast
      //left engine reverse
      ledcWrite(_IN3_PWM_channel, 0);
      ledcWrite(_IN4_PWM_channel, _slowSpeed);// slow
      _LLP=1;
    }
  }else if((!a && !b && c) && ((_LLP!=3)&&(_LLP!=13))){
    if(_LLP==1 || _LLP == 11 || _LLP ==0){
      ledcWrite(_IN2_PWM_channel, 0);
      ledcWrite(_IN4_PWM_channel, 0);
      _timeOut=millis();
      _LLP=13;
      #ifdef DEBUG
      Serial.print("Halt!");
      #endif
    }else{
      //right engine reverse
      ledcWrite(_IN1_PWM_channel, _slowSpeed);// slow
      ledcWrite(_IN2_PWM_channel, 0);
      //left engine forward
      ledcWrite(_IN3_PWM_channel, _averageSpeed);// fast
      ledcWrite(_IN4_PWM_channel, 0);
      _LLP=3;
    }
  }else if((!a && !b && !c) && (_LLP!=0)){
    if(((_LLP==1)||(_LLP==11)) && (!digitalRead(_LLS1)) ){
      ;
    }else if(((_LLP==3)||(_LLP==13)) && (!digitalRead(_RRS5)) ){
      ;
    }else{
      _LLP=0;
      _timeOut=millis();
    }
  }
  interrupts();
  #ifdef DEBUG
  Serial.println(_LLP);
  #endif
}

void robotOnLine::beginAutoDrive()
{
  //attachInterrupt(digitalPinToInterrupt(_LLS1), _think, CHANGE);
  attachInterrupt(digitalPinToInterrupt(_LS2), _think, CHANGE);
  attachInterrupt(digitalPinToInterrupt(_MS3), _think, CHANGE);
  attachInterrupt(digitalPinToInterrupt(_RS4), _think, CHANGE);
  //attachInterrupt(digitalPinToInterrupt(_RRS5), _think, CHANGE);
  attachInterrupt(digitalPinToInterrupt(_CLP), _think, RISING);
  //begin();
}

void robotOnLine::endAutoDrive()
{
  detachInterrupt(digitalPinToInterrupt(_LS2));
  detachInterrupt(digitalPinToInterrupt(_MS3));
  detachInterrupt(digitalPinToInterrupt(_RS4));
  detachInterrupt(digitalPinToInterrupt(_CLP));
}

byte robotOnLine::autoDrive(byte order)
{ 
  byte returnFlag=0;
  #ifdef doSpeedAdjustment
  //adjust speed
  {
    //Serial.print(_maneuver);
    if ((_maneuver == 0) && (_fixDirAlways) && (!_encoderOsc))
    { //if the robot drove a straight line, no manouvers made.
    //Serial.print(".");
    int16_t _lV=0, _rV=0;
    _lV=PC0.getCount();
    _rV=PC1.getCount();
      if ( (_lV > _rV +_eso) || (_lV < _rV - _eso) || (_rV > _lV +_eso) || (_rV < _lV - _eso) )
      { //do encoder values match? if they don't
        byte buffEncoderAhead = _encoderAhead;
        if ((_lV - _rV) > 0)
        {
          //left encoder is going faster
          byte buffer = (buffEncoderAhead & 0xF0) >> 4; // copy "left" data into a buffer
          buffer++;                                     // increment the buffer
          buffEncoderAhead &= 0x0F;                         //erase "left" data
          _encoderAhead = (buffer << 4) | buffEncoderAhead; //save new "left" data

          _speedAdjL++;
          //Serial.println("<<< faster");
        }
        else if ((_rV - _lV) > 0)
        {
          //right encoder is going faster
          byte buffer = (buffEncoderAhead & 0x0F); //copy "right" data into a buffer
          buffer++;                                // increment the buffer
          buffEncoderAhead &= 0xF0;                           //erase "right" data
          _encoderAhead = buffEncoderAhead | (buffer & 0x0F); //save new "right" data

          _speedAdjR++;
          //Serial.println(">>> faster");
        }
        
        if (!_encoderOsc)
        { //verificar se os motores estão  a oscilar
          buffEncoderAhead = _encoderAhead;
          if (((buffEncoderAhead & 0xF0) > 0) && ((buffEncoderAhead & 0x0F) > 0)) //if the speed has been adjusted in both wheels
          {
            if (((buffEncoderAhead & 0xF0) >> 4) == ((buffEncoderAhead & 0x0F)+1))
            {
              _encoderOsc = 1;
              _speedAdjR = 0;
              _speedAdjL = 0;
              //Serial.println("speed oscilation");
            }
            else if (((buffEncoderAhead & 0xF0) >> 4) == ((buffEncoderAhead & 0x0F)-1))
            {
              _encoderOsc = 1;
              _speedAdjR = 0;
              _speedAdjL = 0;
              //Serial.println(">>speed oscilation<<");
            }
          }
        }
      }
      else
      { //if they match, let's keep that in mind
        _lastEncoderOffsetMatch = 1;
        //Serial.println("speed does match");
      }
    }
  }
  #endif
  
  static byte dist = 0;
  byte _dist = distance();
  static unsigned long _distCheckStamp=0;

  if( millis() - _distCheckStamp > 500 )
  {
    dist=_dist;
    _distCheckStamp=millis();
  }

  if(_dist<dist)
  {
    dist=_dist;
  }

  byte d[8] = {0, 0, 0, 0, 0, 0, 0}; // 0 (impact switch), 1 (far left) , 2 (left) , 3 (middle),

  if(!_disableCLPSensor)
  {
    d[0] = digitalRead(_CLP); // 0V when nothing found
  }else{
    d[0] = 0;
  }

  if(!_disableNearSensor){
    d[6] = digitalRead(_Near); // 0V when nothing found
  }else{
    d[6]=0;
  }
  
  if ( !_disableUltrasonicSensor && (dist <= _stopDistance))
  {
    stopMotors();
    returnFlag=2; _timeOut=0; _LLP=5;
  }
  else if((d[6]) || (d[0]))
  {
    stopMotors();
    returnFlag=2; _timeOut=0; _LLP=5;
  }
  else if( (_LLP==5) && ( (!_disableUltrasonicSensor) && (dist > _stopDistance) )) //The robot has stopped, interrupts ain't trigger with it stopped, let's check if it can advance now
  {
    //Ultrasonic CLP and near sensor have already been checked at this point
    bool a=0,b=0,c=0;
    a=!digitalRead(_LS2);
    b=!digitalRead(_MS3);
    c=!digitalRead(_RS4);
    // a,b or c is 1 if a line is found.
    if( ((a&&b) || (b&&c) || (a&&c)) && (_LLP!=4) ){
      if(a){  //checking if this is a false alarm, may happen during curves
        if(!digitalRead(_LLS1)){ //if  line found on far left, false alarm
          stopMotors();
          _LLP=4;
        }
      }else if(c){
        if(!digitalRead(_RRS5)){ //if  line found on far right, false alarm
          stopMotors();
          _LLP=4;
        }
      }
    }else if((!a && b && !c) && (_LLP!=2)){
      forward(_fastSpeed);
      _maneuver=0; _LLP=2;
    }else if((a && !b && !c) && ((_LLP!=1)&&(_LLP!=11))){
      rotateLeft(_fastSpeed);
      _LLP=1;
    }else if((!a && !b && c) && ((_LLP!=3)&&(_LLP!=13))){
      rotateRight(_fastSpeed);
      _LLP=3;
    }else if((!a && !b && !c) && (_LLP!=0)){
      _LLP=0;
    }
  }

  //the next function will stop the robot after x time without a line found.
  if( (_LLP==0 || _LLP==14) && (_timeOut!=0)) //if no lines were found on last check and timeout isn't zero
  {
    if(millis() - _timeOut > _dif)
    {
      stopMotors();
      _timeOut=0;
    }
  }else if((_LLP==13) && (_timeOut!=0)){
    if(millis() - _timeOut > _invDel)
    {
      rotateRight(_fastSpeed);
      _timeOut=0;
    }
  }else if((_LLP==11) && (_timeOut!=0)){
    if(millis() - _timeOut > _invDel)
    {
      rotateLeft(_fastSpeed);
      _timeOut=0;
    }
  }

  //The decision making of the robot is done in the _think function interruption
  //The _LLP variable returns information from it.
  switch (_LLP)
  {
    /*  _LLP values:
        0 no line found.
        1 line of left
        2 line on middle
        3 line on right
        4 multiple lines found
        5 obstacle found

        returnFlag values:
        0 - nothing2report
        1 - multiple lines found
        2 - obstacle found
        3 - no lines found
    */
    case 0:
      returnFlag=3;
      break;
  
    case 4:
      returnFlag=1;
      break;
    
    case 5:
      returnFlag=2;
      break;
    
    default:
    returnFlag=0;
      break;
  }

  //process received instructions
  if((returnFlag == 1) || (returnFlag == 2))
  {//info you can send: 1 turn right'line, 2 turn left'line, 3 forward, 4 reverse
    switch (order)
    {
    case 1:
      noInterrupts();
      rotateRight(_fastSpeed);
      while (digitalRead(_MS3)&&_ec());
      forward(_fastSpeed);
      interrupts();
      break;
    
    case 2:
      noInterrupts();
      rotateLeft(_fastSpeed);
      while (digitalRead(_MS3)&&_ec());
      forward(_fastSpeed);
      interrupts();
      break;
      
    case 3:
      if(returnFlag!=2) //Check if there isn't an obstacle ahead
      {
        forward(_fastSpeed);
      }
      break;
      
    case 4:
      reverse(_fastSpeed);
      break;
      
    default:
      break;
    }
  }

  //Clear teh encoders value in the end
  //If the encoders value aren't cleared the code may fail to adjust wheels speed
  clearEncoderCount();

  return returnFlag;
  /*
  0 - nothing2report
  1 - multiple lines found
  2 - obstacle found
  3 - no lines found
  */
}

bool robotOnLine::_ec()
{
  if((!_disableCLPSensor) && (digitalRead(_CLP)==1))  // a low level means a obstacle
  {
    return 0;
  }else if((!_disableNearSensor) && (digitalRead(_Near)==1) )
  {
      return 0;
  }else if(!_disableUltrasonicSensor){
    byte d = distance();
    if(d<=_stopDistance)
      return 0;
  }
  return 1;
}

void robotOnLine::noLineDelay(uint _k)
{ //After no lines are detected, how much time should it take to stop?
  _dif=_k;
}

void robotOnLine::steerLeft(byte _sp)
{
  //right engine forward
  ledcWrite(_IN1_PWM_channel, 0);
  ledcWrite(_IN2_PWM_channel, _sp);
  //left engine forward but slower
  ledcWrite(_IN3_PWM_channel, _sp-50);
  ledcWrite(_IN4_PWM_channel, 0);
}

void robotOnLine::steerRight(byte _sp)
{
  //right engine forward but slower
  ledcWrite(_IN1_PWM_channel, 0);
  ledcWrite(_IN2_PWM_channel, _sp-50);
  //left engine forward
  ledcWrite(_IN3_PWM_channel, _sp);
  ledcWrite(_IN4_PWM_channel, 0);
}

void robotOnLine::rotateLeft(byte speed)
{
  //right engine forward
  ledcWrite(_IN1_PWM_channel, 0);
  ledcWrite(_IN2_PWM_channel, speed);
  //left engine reverse
  ledcWrite(_IN3_PWM_channel, 0);
  ledcWrite(_IN4_PWM_channel, speed);
}

void robotOnLine::rotateRight(byte speed)
{
  //right engine reverse
  ledcWrite(_IN1_PWM_channel, speed);
  ledcWrite(_IN2_PWM_channel, 0);
  //left engine forward
  ledcWrite(_IN3_PWM_channel, speed);
  ledcWrite(_IN4_PWM_channel, 0);
}

void robotOnLine::stopMotors()
{
  ledcWrite(_IN1_PWM_channel, 0);
  ledcWrite(_IN2_PWM_channel, 0);
  ledcWrite(_IN3_PWM_channel, 0);
  ledcWrite(_IN4_PWM_channel, 0);
}

void robotOnLine::forward(byte speed)
{         
  //Right wheel forward                              
  ledcWrite(_IN1_PWM_channel, 0);
  ledcWrite(_IN2_PWM_channel, abs(speed-_speedAdjR));
  //Left wheel forward
  ledcWrite(_IN3_PWM_channel, abs(speed-_speedAdjL));
  ledcWrite(_IN4_PWM_channel, 0);
}

void robotOnLine::reverse(byte speed)
{
  ledcWrite(_IN1_PWM_channel, abs(speed-_speedAdjR));//R
  ledcWrite(_IN2_PWM_channel, 0);//R
  ledcWrite(_IN3_PWM_channel, 0);//L
  ledcWrite(_IN4_PWM_channel, abs(speed-_speedAdjL));//L
}

void robotOnLine::leftWheel(short dutty)
{
  bool negative=0;
  if(dutty>255)
  {
    dutty=255;
  }else if(dutty<0){
    negative=1;
    dutty=abs(dutty);
    if(dutty>255){dutty=255;}
  }
  if(negative){
  //left engine reverse
  ledcWrite(_IN3_PWM_channel, 0);
  ledcWrite(_IN4_PWM_channel, dutty);
  }else{
  //left engine forward
  ledcWrite(_IN3_PWM_channel, dutty);
  ledcWrite(_IN4_PWM_channel, 0);
  }
}
void robotOnLine::rightWheel(short dutty)
{
  bool negative=0;
  if(dutty>255)
  {
    dutty=255;
  }else if(dutty<0){
    negative=1;
    dutty=abs(dutty);
    if(dutty>255){dutty=255;}
  }
  if(negative){
  //right engine reverse
  ledcWrite(_IN1_PWM_channel, dutty);
  ledcWrite(_IN2_PWM_channel, 0);
  }else{
  //right engine forward
  ledcWrite(_IN1_PWM_channel, 0);
  ledcWrite(_IN2_PWM_channel, dutty);
  }
}

void robotOnLine::begin()
{
  //configure the pins
  _config();

  // Initialize pulse counter modules
  PC0.begin(_wheelL);
  PC1.begin(_wheelR);

  
  //setup PWM for motor pins
  ledcSetup(_IN1_PWM_channel, PWM_Frequency, PWM_RESOUTION);
  ledcAttachPin(_IN1, _IN1_PWM_channel);

  ledcSetup(_IN2_PWM_channel, PWM_Frequency, PWM_RESOUTION);
  ledcAttachPin(_IN2, _IN2_PWM_channel);

  ledcSetup(_IN3_PWM_channel, PWM_Frequency, PWM_RESOUTION);
  ledcAttachPin(_IN3, _IN3_PWM_channel);

  ledcSetup(_IN4_PWM_channel, PWM_Frequency, PWM_RESOUTION);
  ledcAttachPin(_IN4, _IN4_PWM_channel);

  ledcWrite(_IN1_PWM_channel, 0);
  ledcWrite(_IN2_PWM_channel, 0);
  ledcWrite(_IN3_PWM_channel, 0);
  ledcWrite(_IN4_PWM_channel, 0);

}

void robotOnLine::turnLeft(uint16_t deg)
{
  if (deg == 0)
  {
    deg = 90;
  }
  if (deg < 361)
  {
    clearEncoderCount();
    //40 count = 1 turn = 180 deg
    byte steps = ((deg * 80) / 360);

    rotateLeft(_fastSpeed);
    while (PC0.getCount() < steps)
      ;
    stopMotors();
  }
}

void robotOnLine::turnRight(uint16_t deg)
{
  if (deg == 0)
  {
    deg = 90;
  }
  if (deg < 361)
  {
    clearEncoderCount();
    //40 count = 1 turn = 180 deg
    byte steps = ((deg * 80) / 360);
    
    rotateRight(_fastSpeed);
    while (PC1.getCount() < steps);
    stopMotors();
  }
}

void robotOnLine::setSpeeds(byte _f,byte _a,byte _s)
{
  _fastSpeed=_f;
  _averageSpeed=_a;
  _slowSpeed=_s;
}

bool robotOnLine::readCLP()
{
  return digitalRead(robotOnLine::_CLP);
}
bool robotOnLine::readNear()
{
  return digitalRead(_Near);
}
bool robotOnLine::readS1()
{
  return digitalRead(_LLS1);
}
bool robotOnLine::readS2()
{
  return digitalRead(robotOnLine::_LS2);
}
bool robotOnLine::readS3()
{
  return digitalRead(robotOnLine::_MS3);
}
bool robotOnLine::readS4()
{
  return digitalRead(robotOnLine::_RS4);
}
bool robotOnLine::readS5()
{
  return digitalRead(_RRS5);
}

